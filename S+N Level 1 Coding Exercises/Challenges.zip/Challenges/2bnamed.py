def is_empty(s):
    print(False) if (s.isalnum() or s.isspace() or not s.isalnum()) else print(True)
		
is_empty("")

def xo(a):
	b=[i for i in a.lower()]
	c=b.count("x")
	d=b.count("o")
	return True if c==d else return False