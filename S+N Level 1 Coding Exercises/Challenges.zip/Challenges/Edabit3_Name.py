





class Employee:
	def __init__(self,firstname,lastname):
		self.fname=firstname.title()
		self.lname=lastname.title()
		
		
	@property
	def fullname(self):
		return "{0} {1}".format(self.fname,self.lname).title()
		
		
	@property
	def email(self):
		return "{0}.{1}@company.com".format(self.fname,self.lname).lower()
								
		
a1=Employee("jOHn", "SunMOlA")
a1.fname="mujeeb"

print(a1.fullname)
print(a1.email)
print(a1.fname)