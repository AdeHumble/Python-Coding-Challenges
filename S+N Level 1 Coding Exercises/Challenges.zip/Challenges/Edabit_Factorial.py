



def factorial(number):
	fact=1
	
	if number<0:
		return "Number must be a postive integer!"
		
	elif number==0:
		return "The factorial of {number} is {fact}"
		
	else:
		while number>=1:
			fact=fact*number
			number-=1
		return "The factorial of {number} is {fact}"
	

factorial(5)






