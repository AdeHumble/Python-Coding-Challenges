class Person:
	def __init__(self,name,like,hate):
		self.name=name
		self.like_food_list=like
		self.hate_food_list=hate
		
		
	def taste(self, choice):
		self.choice=choice
		
		if self.choice in self.like_food_list:
			return "{0} eats the {1} and loves it!". format(self.name, self.choice)
			
		elif self.choice in self.hate_food_list:
			return "{0} eats the {1} and hates it!". format(self.name, self.choice)
		
		else:
			return "{0} eats the {1}!". format(self.name, self.choice)


p1=Person("Samson", ["icecream","bread", "potato"], ["carrot","sugar"])
p2=Person("Shola",[],["yam","egg"])

print(p2.like_food_list)

print(p1.taste("yam"))