



Flavor_SV={"Plain":0, "Vanilla":5, "ChocolateChip":5, "Strawberry":10, "Chocolate":10}



class IceCream:
	def __init__(self, flavor, num_sprinkles):
		global answer
		self.flavor=flavor.title()
		self.num_sprinkles=num_sprinkles
		
		if self.flavor in Flavor_SV.keys():
			answer=[self.num_sprinkles+Flavor_SV.get(self.flavor)]
			print(answer)
			
		else:
			print(f"{self.flavor} is not in the list of flavors")
		
		
ice1=IceCream("strawberry",7)
ice2=IceCream("chocolate",13)



#def sweetest_icecream():
#	print(ice1)
#	

#sweetest_icecream()