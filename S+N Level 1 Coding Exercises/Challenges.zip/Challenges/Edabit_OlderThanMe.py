class Person:
	def __init__(self,name,age):
		self.name=name
		self.age=age
	
	def compare_age(self, other):
		if other.age < self.age:
			s = 'younger than'
		elif other.age > self.age:
			s = 'older than'
		elif other.age == self.age:
			s = 'the same age as'
		print(f'{other.name} is {s} me.')
		
				
p1=Person("Samuel", 24)
p2=Person("Joel", 36)
p3=Person("Lily", 24)

p1.compare_age(p2)
p2.compare_age(p1)
p1.compare_age(p3)
p3.compare_age(p1)
p2.compare_age(p3)