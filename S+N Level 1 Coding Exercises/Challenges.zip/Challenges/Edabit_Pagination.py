class Pagination:

	def __init__(self, items=[], pageSize=10):
		self.items = items
		self.pageSize = pageSize
		self.totalPages = 0
		self.currentPage = 0
		
	def getItems(self):
		
	def getPageSize(self):
		
	def getCurrentPage(self):
  	
	# Goes to the previous page
	def prevPage():
		
	# Goes to the next page
	def nextPage():
		
    # Goes to the first page
	def firstPage():
		
    # Goes to the last page
	def lastPage():
		
    # Goes to a page determined by the `page` argument
	def goToPage(page):
		
   # Returns the currently visible items as an array
	def getVisibleItems():
		