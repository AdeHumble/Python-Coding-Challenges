#Weekly Coding Challenge


#Function Program
def fizzbuzz(expected_no):
	for num in range(1,expected_no + 1):
		if num%3==0 and num%5==0:
			print("FizzBuzz")
		elif (num%3==0):
			print("Fizz")
		elif (num%5==0):
			print("Buzz")
		else:
			print(num)

print("Welcome to FIZZBUZZ game!.\n")
print("|||||"*24)
print("INFORMATION ABOUT THE GAME\nThis game is all about printing out all numbers starting from 1 to any number of your choice.\nThe only exceptions are:\n\t1)'Fizz' will be printed if the number is divisible by 3\n\t2)'Buzz' will be printed if the num er is divisible by 5\n\t3)'FizzBuzz' will be printed if the number is divisible by both 3 and 5\n\t4)Else, it'll print the real number")
print("|||||"*24)

#Main Program
while True:
	try:
		user_no=int(input("Enter any number of your choice: "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a postive integer.\nPlease, Try again!")
		print("|||||"*24)
		
fizzbuzz(user_no)