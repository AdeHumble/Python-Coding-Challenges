#Test case
case=[["F", "A", "C", "I"],
["O", "B", "Q", "P"],
["A", "N", "O", "B"],
["M", "A", "S", "S"]
]
#Initialisation Parameters
item=[]
column=[]
up2down=[]
row=[]
left2right_ans=[]
all_possible_ans=[]
#Function Program
def find(array,word):
	count=0
	#Finds all possible combinations from up to down	
	for i in range(len(array)):	
		for j in array:
			count+=1
			item.append(j[i])
			if count==len(array):
				column.append("".join(item))
				count=0
				up2down.extend(column)
				del item[:]
		up2down_ans=list(set(up2down))
	#Finds all possible combinations from left to right	
	for i in array:
		row="".join(i)
		left2right_ans.append(row)
	#Combines both possible answers	
	all_possible_ans.extend(up2down_ans)
	all_possible_ans.extend(left2right_ans)
	#Check if the target word is presebt or not
	if word in all_possible_ans:
		return f"{word} can be found"
	else:
		return f"{word} cannot be found"
	
target_word=input("Enter the word you wish to find: ").upper()	
find(case,target_word)	