
car_list=[30, 15, 60, 75, 45, 15, 15, 45]

def my_cars(cars):
	ans=[]
	fact=len(cars)
		
	for i in range(0,fact,2):
		if (fact%2!=0):
			ans.append(cars[i])
			continue
		
		elif (fact%2==0):
			if i != fact-2:
				ans.append(cars[i])
			elif i == fact-2:
				if cars[i]>cars[fact-1]:
					ans.append(cars[i])
				else:
					ans.append(cars[fact-1])
					break
	return sum(ans)
	
print("The sum of all maximum possible car worths that can be choosen is: ",my_cars(car_list))