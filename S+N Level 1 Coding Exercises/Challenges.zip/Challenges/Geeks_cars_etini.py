#defines a function to accept the worth each car in the garage in a single line
def my_cars(array):
#determines the number of cars in the garage
    n = len(array)
#Returns 0 if no car is in the garage
    if n == 0:
        return 0
#Returns the price of a car if it is the only one in the garage line
    if n == 1:
        return array[0]
#Returns the greater car price if the garage has 2 cars in a single line
    if n == 2:
        return max(array[0], array[1])
 
#creates a new list called cwl which has the same length as that of the cars in the garage line
    cwl = [3] *n
 
#Replaces the 1st element in cwl with the worth of the first car in array
    cwl[0] = array[0]
#Replaces the 2nd element in cwl with the car with greater worth between the 1st and 2nd
    cwl[1] = max(array[0], array[1])
#from the 3rd car to the nth car; the max worth either when one or two cars are skipped is determined and used to replace cwl[i]
    for i in range(2, n):
        cwl[i] = max(array[i]+cwl[i-2], cwl[i-1])
 
#returns the total max worth ehich is the last element in cwl
    return cwl[-1]
 
  #Accepts input from the user
array = list(int(num) for num in input("Enter numbers separated by commas: ").split(","))
print(my_cars(array))