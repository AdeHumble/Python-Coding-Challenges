
c=0
for i in range(3): 
    try: 
        c=int(input("Enter a number: ")) 
    except ValueError as e:
    	c+=1
    	if c<3:
    		continue
    	else:
    		print("elapsed!")
    break
print(c)




#action="p"
#while action=="p":

#	try:
#		method=input("How do you wish to search for an item?\nPress 1:To search by item number\nPress 2: To search by name\n  ")

#	except ValueError:
#		print()
#		print("You must enter a number. Pls, try again")
#		continue

#	if (method==1):
#		print(1)
#	else:
#		print(2)





#answers=[]
#answer=" "

#letters={"A":10, "B":7, "CD":4, "E":1, "F":6, "G":1}

#for letter,number in letters.items():
#	answers.append(letter*number)

#for ans in answers:
#	answer+=ans
#	
#print(answer)

#...................

#name=input("Welcome friend! I would like to meet you. Please, kindly tell me your name: ").title()

#while True:
#	try:
#		num=abs(int(float(input(f"\nNice to meet you {name}. How many times do you want me to say your name?: "))))
#		break
#	except ValueError:
#		print("That's not a number! Please, try again \n")
#		

#print(f"\nOkay! I'll say your name {num} times.\n")		
#			
#for n in range(num):
#	print(f"Your name is {name}")

print("Welcome! I'll help you convert any length in centimetres to inches.")
print()

while True:
	try:
		num=float(input("Enter the length in centimetres: "))
		break
	except ValueError:
		print("Oops! That is not a number. Try again!\n")
		
if num<0:
	print("Invalid input! You must provide a positive number.")	
	
else:
	answer=num/2.54
	length_in_inches=format(answer,".2f")
	print("\n{}cm is = {}inches".format(num,length_in_inches))
	
