def encrypt(word):
	ans=[]
	vowel_chart={"a":"0", "e":"1", "i":"2", "o":"2", "u":"3"}
	
	reversed=[i for i in word[::-1]]
	
	for j in reversed:
		if j in vowel_chart:
			eqv=vowel_chart[j]
			ans.append(eqv)
		else:
			ans.append(j)
					
	return "".join(ans)+"aca"		
encrypt("burak")