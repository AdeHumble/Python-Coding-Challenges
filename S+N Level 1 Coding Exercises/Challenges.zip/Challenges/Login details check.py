# username="scholar"
# password="python"

# user=str(input('Please, enter your username, '))
# passw=str(input('Please, enter your password, '))
# if (user==username and passw==password):
# 	print("Correct! You can now proceed")
# else:
# 	print("Incorrect username or password. please, try again.")
# 	print("Remember username and password are case sensitive")
    
    
    
    
    
    
user_name='adeyanju'
pass_word='blessing'
count=0
count1=0

username=input('Enter your username: ').lower().strip()
while username==user_name:
    print('\nWelcome', username, "\nPLease enter your pasword to further verify your identity")
    password=input('Enter your password: ').lower().strip()
    
    if password==pass_word:
        print('You have succesfully logged in into your account')
        break
    
    elif password!=pass_word:
        count+=1
        if count<=2:
            print('Incorrect password. Please, try entering your password again')
            continue
        
        else:
            print('\nYou have exceeded your trial limits\nThis software is shutting down now....!')
            break

while username!=user_name:
    
    if count<=2:
        username=input('That was a wrong username. Please try again: ').strip().lower()
        if username==user_name:
            print('\nWelcome', username, "\nPLease enter your pasword to further verify your identity")
            count1=0
            pass_word=='blessing'
            password=input('Enter your password: ').lower().strip()
            while pass_word!=password:
                password=input('Enter your password: ').lower().strip()
                count1+=1
                if count1<=2:
                    continue
                else:
                    print('\nYou have exceeded your trial limits\nThis software is shutting down now....!')
                    break

            else:
                print('\nYou have succesfully logged in into your account')
                
           
    else:
        print('\nYou have exceeded your trial limits\nThis software is shutting down now....!')
        break
