#Program to Generate Random Multiplication Questions for a user and test if the the user's answer is right or wrong


import random

#This is the program built-in questions
Questions_Answers={

"Question 1: 8 * 9": 72,
"Question 2: -4 * 9": -36,
"Question 3: -8 * -2": 16,
"Question 4: 0 * 5": 0,
"Question 5: 12.5 * 2": 25,
"Question 6: 10 * 12": 120,
"Question 7: 23 * 2": 46,
"Question 8: 21 * 9": 189,
"Question 9: 18 * 5": 90,
"Question 10: 0 * 0": 0,
"Question 11: 14.5 * 2": 29,
"Question 12: 0.5 * 2": 1

}


Questions_list=[Questions for Questions in Questions_Answers.keys()]

Answers_list=[Answers for Answers in Questions_Answers.values()]	

Question=random.choice(Questions_list)
	
position=Questions_list.index(Question)
	
print("Provide your answer")
print(Question, "= ", end="")
answer=int(input())
	
if answer==Answers_list[position]:
	print("Correct!")
elif answer!=Answers_list[position]:
	print("Wrong!")		