



print("\t\tSMART NUMBER BASE CALCULATOR")
print("\n")
print("What do u want to do?\nA) I want to convert from base 10 to other number base\nB) I want to convert from any number base to base 10")
print("\n")

#This will accepts a user choice
users_choice=input("Indicate your choice above by selecting option 'A' or 'B':  ").upper()
print("\n")

#The following lines will convert from base 10 to any number base. One interesting thing is that, it'll keep prompting the user for the correct format or data type of all expected inputs
if  users_choice=="A":
	print("\tDear user, just to remind you, i'll be helping you to convert from base 10 to any other number base of your choice. LET'S GET STARTED!")
	print("\n")
	while True:
		try:
			users_num=abs(int(float(input('Enter the number in base 10: '))))
			break
		except ValueError:
			print("That is a wrong input! I am expecting a positive integer. Please try again.")
			print("\n")
	while True:
		try:
			base=abs(int(float(input("Enter the number base you would like to convert to: "))))
			break
		except ValueError:
			print("That is a wrong input! I am expecting a positive integer. Please try again.")
			print("\n")
#Now, we have come to the most technical part...smiles.
	rem_list=[]
	answer=""
	main=users_num
	while main>=base:
		rem=main%base
		if rem==10:
			rem_list.append("A")
		elif rem==11:
			rem_list.append("B")
		elif rem==12:
			rem_list.append("C")
		elif rem==13:
			rem_list.append("D")
		elif rem==14:
			rem_list.append("E")
		elif rem==15:
			rem_list.append("F")
		else:
			rem_list.append(rem)
		main=main//base
	if main<base:
		rem_list.append(main)
	for r in rem_list[::-1]:
		answer=answer+str(r)
	print(users_num,"in base 10 is:",answer, "in base",base)
	

#The following lines will convert from any number base to base 10. One interesting thing is that, it'll keep prompting the user for the correct format or data type of all expected inputs
elif users_choice=="B":
	print("\tDear user, just to remind you, i'll be helping you to convert from any number base of your choice to base 10. LET'S GET STARTED!")
	print("\n")
	answer=0
	while True:
		try:
			base=abs(int(float(input("What number base do you wish to convert to base 10? "))))
			break
		except ValueError:
			print("That is a wrong input! I am expecting a positive integer. Please try again.")
			print("\n")
	while True:
		try:
			users_num=abs(int(float(input("Enter the number: "))))
			break
		except ValueError:
			print("That is a wrong input! I am expecting a positive integer. Please try again.")
			print("\n")
#Many things are going down here too
	num_list= [int(n) for n in str(users_num)]
	p=len(num_list)
	for q in num_list:
		p=p-1
		answer=answer + (q* base**p)
		if p<0:
			break
	print(users_num,"in base", base,"is:", answer, "in base 10")

else:
	print("You entered an incorrect option. Your choices are only limited to A or B. Please, try again!")
	
	





















#x=19.52

#B=str(x).split(".")
#print(B)
#c=int(B[0])
#d=int(B[1])
#print(c+d)

#for i in range(len(B)):
#	whole=int(B[i])
#	fraction=int(B[i])

#print(whole)
#print(fraction)
	