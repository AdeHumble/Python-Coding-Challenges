def check4square(num):
	all_squares=[float(i*i) for i in range(1,num)]
	actual=num**0.5	
	print(num, "is a perfect number") if num in all_squares else print(num, "is not a perfect number")

user_input=abs(int(float(input("Enter the number: "))))
check4square(user_input)