import re

sentence=input("Enter your sentence: ")

word_list=re.split("\s",sentence)

def func(length):
	return len(length)
	
wordlist=sorted(word_list,key=func)
new_sentence=" ".join(wordlist)

print(f"Your original sentence was:\n{sentence}\n")
print(f"Based on the length of each word in your sentence, your sentence has been rearanged to: \n{new_sentence}")


#def sorter(lists):
#	box=[]
#	new={}
#	house=[]
#	for i in lists:
#		box.append(len(i))
#		box.sort()
#	for k in box:
#		for j in lists:
#			if k==len(j):
#				new[j]=k
#	for i in new.keys():
#		house.append(i)
#	general = " ".join(house)
#	return general
#	
#lists= input("Input You word : ").split(" ")
#print(sorter(lists))





#sentence=input("Enter your sentence: ")

#word_list = sentence.split(" ")
#	
#wordlist=sorted(word_list,key=len)
#new_sentence=" ".join(wordlist)

#print(f"Your original sentence was:\n{sentence}\n")
#print(f"Based on the length of each word in your sentence, your sentence has been rearanged to: \n{new_sentence}")