print("This program is written to make the first number as large as possible by swapping out it digits for the digits in the second number without repetition.\n \nSimply put, it returns the highest possible combinations of a number by manipulation.")
print("*****"*24)

#FUNCTION PROGRAM
def max_possible(num1,num2):
	answerlist=[]
	answer=""
	numlist1=[]
	numlist2=[]

	#This will return a string of splitted digits in each respective inputs
	numlist1.extend("".join(num for num in str(num1)))
	numlist2.extend("".join(num for num in str(num2)))
	
	#This will turn each digits in the list back to an integer
	num_list1=[int(n) for n in numlist1]
	num_list2=[int(n) for n in numlist2]
	
	for i in num_list1:	
		if i >max(num_list2):
			answerlist.append(i)
			continue		
				
		else:
			b=len(num_list2)
			answerlist.append(max(num_list2))
			num_list2.remove(max(num_list2))
			if len(num_list2)==0:
				answerlist.extend(num_list1[:])	
				break
	
	for j in answerlist:
		answer+=str(j)
	print(f"The greatest possible number is {int(answer)}")	
	
#MAIN PROGRAM
#This will accepts the first number.It's very sensitive to any type of possible wrong inputs
while True:
	try:
		num_1=+abs(int(float(input("Please, enter the first number:"))))
		print("\n")
		break
	except ValueError:
		print("Oops! Thats not a number. You must enter a number without any characters or letters. Please, try again.\n")

#This will accepts the second number.It's also very sensitive to any type of possible wrong inputs
while True:
	try:
		num_2=abs(int(float(input("Please, enter the second number:"))))
		print("\n")
		break
	except ValueError:
		print("Oops! Thats not a number. You must enter a number without any characters or letters. Please, try again.\n")

max_possible(num_1,num_2)