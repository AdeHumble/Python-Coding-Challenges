vowels=["a", "e", "i", "o", "u"]
wordvowels=[]
word=input("please, enter any word, ")
for i in word:
	if i==vowels[0]:
		wordvowels.append(vowels[0])
	elif i==vowels[1]:
		wordvowels.append(vowels[1])
	elif i==vowels[2]:
		wordvowels.append(vowels[2])
	elif i==vowels[3]:
		wordvowels.append(vowels[3])
	elif i==vowels[4]:
		wordvowels.append(vowels[4])
print(wordvowels)	
