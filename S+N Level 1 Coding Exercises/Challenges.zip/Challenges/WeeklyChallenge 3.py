
#FUNCTION PROGRAM
def number_pair_sum(user_numbers,constant):
	answer=[]
	for user_num in user_numbers:
		for num in range(len(user_numbers)):
			if user_num==user_numbers[num]:
				continue
			ans=user_num + user_numbers[num]
			answer.append(ans)
	print("The sum of each number pairs are: ", answer)		
	print("\n")		
	if constant in answer:
			print("True")
	else:
		print("None of the sum of the pairs of", user_numbers,"is =", constant)
	

#MAIN PROGRAM
#number_list=[]
numbers=[]

while True:
	try:
		num=int(float(input("How many numbers do you want to play with? ")))
		#A user can may be funny to enter a float number. i dont want the program to stop because of that.i use float to take care of that exception. i tried using 'eval' to take care of both 'int' and 'float', but it doesnt work.
		break
	except ValueError:
		print("That is a wrong input. Make sure you enter a number. Please, try again!")
		print("\n")

print("\n")
#Since it's now clear that the user want to enter 'num' numbers (say 5 nos for example).In order to accepts those 5 differnt numbers IN TURN, that is why i will be using the for loop below.
	
for n in range(num):
	while True:# This will make sure that only inputs that are integers are accepted (i.e. while it is True that the input is an integer)
		try:
			number=int(input("Please, enter those number choices one after the other: "))
			break #This break statement will stop the try block. i mean if the user enters what i want, break the try block and enter another number.
		except ValueError:
			print("That is a wrong input. Make sure you enter an integer. Please, try again!")
			print("\n")
	numbers.append(number)

print("\n")		
while True:
	try:
		fixed_number=int(input("Enter the number you would like to compare to the sum of each pair of your number choices: "))
		break
	except ValueError:
		print("That is not a number. Make sure to enter a number.Please, try again!")
		print("\n")

print("\n")
print("Your number choices are: ",numbers)
print("\n")
number_pair_sum(numbers, fixed_number)
