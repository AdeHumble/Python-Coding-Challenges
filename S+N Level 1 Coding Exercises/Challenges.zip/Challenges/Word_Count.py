
import math
bad_chars = [';', ':', '!', "*", ",", "."] 
answer1=""
answer2=[]
count=0

words=input("Enter any sentence: ")

for word in words:
	if not word.isalpha():
		continue
	answer1+=word
	
	#if word.isalpha or word=="":
		#answer2.append(word)

for ans in answer1:
	count+=1
print(answer1)
print(count)

#print(answer2)


answer2=''.join(i for i in words if not i in bad_chars)
print(answer2)
answer3=answer2.split(" ")
print(len(answer3))	



result=len(answer1)/len(answer3)
print(math.ceil(result))