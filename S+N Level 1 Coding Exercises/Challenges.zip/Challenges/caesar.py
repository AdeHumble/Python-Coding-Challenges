import string

coded=[]
choice="y"
l_alpha=list(string.ascii_lowercase)
u_alpha=list(string.ascii_uppercase)
	
#Function to Encrypt
def encryption(sentence):
	for i in sentence:
		if i in l_alpha:
			id=l_alpha.index(i)-3
			coded.append(l_alpha[id])
			
		elif i in u_alpha:
			id=u_alpha.index(i)-3
			coded.append(u_alpha[id])
			
		elif not i.isalpha():
			coded.append(i)
	
	encrypted="".join(coded)
	
	print(encrypted)

#Function to Decrypt	
def decryption(sentence):
	for i in sentence:
		if i in l_alpha:
			id=l_alpha.index(i)
			if id>22:
				id=id-23
				coded.append(l_alpha[id])
			else:
				id+=3
				coded.append(l_alpha[id])
			
		elif i in u_alpha:
			id=u_alpha.index(i)
			if id>22:
				id=id-23
				coded.append(u_alpha[id])
			else:
				id+=3
				coded.append(u_alpha[id])
			
		elif not i.isalpha():
			coded.append(i)
	
		decrypted="".join(coded)
	
	print(decrypted)
	

while (choice != "Q" or choice !="q"):		
	choice=input("What would you like to do?\nPress 'A': To encrypt a message\nPress 'B': To decrypt a message\n ")
	
	if (choice == "A" or choice == "a"):
		print()
		message=input("Enter the sentence you would like to encrypt: ")
		print(f"Your message has been encrpted to: ", end="")
		encryption(message)
		print("\nYou may press 'Q' to quit")
		print()
		
	elif (choice=="B" or choice == "b"):
		print()
		message=input("Enter the sentence you would like to decrypt: ")
		print(f"Your message has been decrypted. Your original message was: ", end="")
		decryption(message)
		print("\nYou may press 'Q' to quit")
		print()
		
	elif (choice =="Q" or choice == 'q'):
		print()
		print("Thank you. Pls stay safe!")
		break
		
	else:
		print("That was a wrong choice. You can simply press 'Q' to Quit")
		print()