print("\t\tWEEKLY CODING CHALLENGE")
print("\n")
print("This program is written to return a number list whose length is up to 15 or more without repetition of its items\nHAPPY CODING!")
print("\n")


#FUNCTION PROGRAM
def duplicate(number):
	answer=[]
	if len(number)<15:
		print("The length of your number choices is not up to 15. Please, try again!")	
	else:
		for n in number:
			if n not in answer:
				answer.append(n)
		print("Your list of number choices are:",number)
		print("\n")
		print("The list of those numbers without repetition is:", answer)
		print("\n")
		print("The length of the new list without repetition is:", len(answer))
	

#MAIN PROGRAM
number_list=[]
num_list=[]
print("You are about to be prompted for your number choices. Remember, you must enter 'Done' when you are okay with your choices.")
print("\n")
while True:
	#using capitalize() to format the input wont allow us to run into trouble in case the user enter "Done" in diferrent cases.
	num=input("Please, enter those numbers one after the other: ").capitalize()
	if num=="Done":
		break
	else:
		num_list.append(num)
		
#The line below will generate an integer list
number_list=[int(i) for i in num_list]

#The line below will also sort the items.in ascending order
number_list.sort()

#Lets call our function to action!
duplicate(number_list)

		

