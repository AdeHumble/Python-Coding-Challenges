def factor_chain(lst):
	l=len(lst)
	ans=[]
	for i in range(l):
		j=i+1
		while j<=l-1:
			ans.append(lst[j]%lst[i])
			
	print(ans)
	
	
factor_chain([3,6,9,12,36])