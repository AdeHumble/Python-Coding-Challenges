#Parameters Initialisation
all_unique_id_list=[]
dict={}
all_dislikes=[]
ind_likes_list=[]
answer=[]

#This extracts information from the text file
with open("handshake.txt", "r") as party:
	#The first line in the text file represents the total number of people at the party
	no_people=int(party.readline().rstrip("\n"))
	#This will iterates over the next lines of the text file
	for i in range(1,no_people):
		file_line=(party.readline().rstrip("\n").split(" "))
		try:
			file_row=[int(j) for j in file_line]
		except ValueError:
			break
		all_dislikes.append(file_row)

		
all_attendees_list=[i for i in range(1,no_people+1)]
all_attendees_set=set(all_attendees_list)

#To match individual unique ID with the people they dislikes
for i in all_dislikes:
	ind_unique_id=i[0]
	all_unique_id_list.append(ind_unique_id)
	dict.update({ind_unique_id:i[1:]})
	
#To find the missing identity	
all_unique_id_set=set(all_unique_id_list)
missing_id=list(all_attendees_set-all_unique_id_set)

#To update the dictionary
for i in missing_id:
	current_attendees=all_attendees_list.copy()
	current_attendees.remove(i)
	dict.update({i:[]})

#The main algorithm
for i in dict:
	current_attendees=all_attendees_list.copy()
	current_attendees.remove(i)
	for j in current_attendees:
		if (j not in dict[i]) and (i not in dict[j]):
			ans=f"{i}:{j}"
			answer.append(ans)
		else:
			continue
			
#Total number of repeated handshakes
answer1=len(answer)
print(f"The total number of handshake is: {round(answer1/2)}")