import pprint
 
N = 10
missing = 0
missing_updated = set()
count = 0
temp = []
 
matrix = { 1: {2,4,5,6},
                2 : {1,3,8,10},
                3 : {1,2,4,10},
}
 
# this keeps track of only a missing key in the matrix above if there is any and it instantiate the missing key with a null set thus modifying the matrix above
for i in range (1, N+1):
    if i not in matrix.keys():
        missing = i
        matrix[i] = set()
 
# the block below generates the equivalent value for the missing key & updates the value of that key
 
''' the logic here is if Sam dislikes Joseph, then, Joseph dislikes Sam
'''
for item in matrix.keys():
    if missing in matrix.get(item):
        missing_updated.add(item)
    if matrix.get(item) == set():
        matrix[item] = missing_updated
 
# this populates a list with each values per key
for item in matrix.values():
    temp.append(item)
 
# the list generated above is changed to a tuple in order for the count method to be used
temp = tuple(temp)
 
# this counts the number of times a value occurs in the tuple object generated above
for i in temp:
    if temp.count(i) > 1:
        count += 1
        handshakes = count - 1
    else:
        handshakes = 0
   
print(handshakes)