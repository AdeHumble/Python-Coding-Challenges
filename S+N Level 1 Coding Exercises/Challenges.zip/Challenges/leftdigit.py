def left_digit(word):
	print([i for i in word if i.isnumeric()])
	
left_digit("ade5yanj8u")