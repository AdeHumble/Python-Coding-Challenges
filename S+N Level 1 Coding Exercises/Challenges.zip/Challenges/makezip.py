from zipfile import ZipFile
with ZipFile("IMS_project.zip", "w") as any:
	any.write("IMS_project.py")
	any.write("IMS_project.txt")
	any. write("IMS_readme.md")
