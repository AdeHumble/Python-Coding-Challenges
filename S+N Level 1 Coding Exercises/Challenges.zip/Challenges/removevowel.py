def remove_vowels(txt):
	z=list(txt.lower())
	v=["a","e","i","o","u"]
	for i in txt:
		if i in v:
			z.remove(i)
	print("".join(z))
	
	
	
remove_vowels("My name is Adeyanju. I am a boy")