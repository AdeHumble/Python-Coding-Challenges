def sort_by_length(lst):
	a=[]
	c=sorted([len(i) for i in lst])
	b={len(i):i for i in lst}
	
	for j in c:
		a.append(b[j])
		
	print(a)
		
		
	
	
	
sort_by_length(["bb","aaaaaa","y","dhgt"])


def sort_by_length(lst):
	return ([{len(i):i for i in lst}[j] for j in sorted([len(i) for i in lst])])