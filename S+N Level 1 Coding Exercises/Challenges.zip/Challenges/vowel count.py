def count_vowels(word):
	vowels=["a","e","i","o","u"]
	count=0
	
	for j in word:
		if j in vowels:
			count+=1
	return count
	
count_vowels("celebration")

#def count_vowels(txt):
#	return sum([1 for x in txt.lower() if x in 'aeiou'])
#  
#import re

#def countVowels(str):
#	return len(re.findall(r'[aeiou]', str))