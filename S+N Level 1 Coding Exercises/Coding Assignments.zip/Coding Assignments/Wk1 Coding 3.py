print("Peanut butter and ", end="")
print("jelly")