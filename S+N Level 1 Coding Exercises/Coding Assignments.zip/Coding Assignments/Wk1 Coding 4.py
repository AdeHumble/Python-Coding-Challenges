season="Winter"

lucky_number=4

hard_math=3+4+5

my_str="3"
my_num=int(my_str)

fancy_name="SUNMOLA, Mujeeb Adeyanju"
print(fancy_name)