#10
def is_palindrome(character):
	while character=="":
		print("You must provide an input. Please try again")
		break
	if character[:]==character[::-1]:
		print("True")
	else:
		print("False")

print("\tHello! Dear User. This program is written to test if a word is a PALINDROME. \n \tIt will prompts a DEFAULT ERROR STATEMENT if you did not supply any input. The program will also AUTOMATICALLY ends. \n \tHave Fun!")
print("_______"*17)
word=input("Enter any word, ")
is_palindrome(word)