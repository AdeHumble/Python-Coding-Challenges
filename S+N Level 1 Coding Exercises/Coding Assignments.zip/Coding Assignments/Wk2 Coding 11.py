#11a
def easy_money():
	print(100)
easy_money()

print("-----"*24)

#11b
def best_food_ever():
	print("Sushi")
best_food_ever()

print("-----"*24)

#11c
#This program is also sensistive of accepting floating numbers
def convert_to_currency(currency):
	Money=str(currency)
	print("$" + Money)
		
Money_Value=int(float(input("enter the value of the currency, ")))

convert_to_currency(Money_Value)
	