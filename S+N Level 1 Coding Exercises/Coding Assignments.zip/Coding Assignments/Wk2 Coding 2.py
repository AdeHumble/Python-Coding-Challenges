#2
#The following lines of codes DEMONSTRATES THIS EXERCISE by accepting the last and first name of a user and prints their corresponding concatenation but returns an empty value if the user decides not to pass in any argument for his/her last name or first name.

def string_adder(a=" ", b=" "):
	return a+" "+b

Last_name=input("Enter your Last name, ")
First_name=input("Enter your First name, ")
print("Welcome!",string_adder(Last_name, First_name))

