#3
#The following lines of codes DEMONSTRATES THIS EXERCISE by returning the product of the ages of a child and his/her two parents.

def multiplier(num1=1, num2=1, num3=1):
	return(num1*num2*num3)

#Here, i also use float to format the input data type, in case the user supplied a float number.

Age1=int(float(input("How old are you? ")))
Age2=int(float(input("Enter your Father's age ")))
Age3=int(float(input("Enter your Mum's age ")))
print("The product of your ages is: ", end=" ")
print(multiplier(Age1*Age2*Age3))
