#4
def long_function(character):
	print(len(character) >7)

print("\tHello! Dear User. This program is written to test that the number of characters in a word is more than 7. \n \tIt will return a FALSE statement if it's otherwise.")
print("_______"*17)

word=input("Please, enter any word of your choice, ")
long_function(word)