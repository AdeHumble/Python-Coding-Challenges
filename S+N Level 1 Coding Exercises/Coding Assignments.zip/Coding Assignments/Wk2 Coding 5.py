#5
def first_longer_than_second(character1, character2):
	if len(character1)>len(character2):
		print(len(character1)!=len(character2))

	elif len(character1)<=len(character2):
		print(len(character1)>len(character2))
		
print("\tHello! Dear User. This program is written to test if the number of characters in your first input is more than that of your second input. \n \tIt will return a FALSE statement if it's otherwise.")
print("_______"*17)
	
word1=input("Enter any first word of your choice, ")
word2=input("Enter any second word of your choice, ")
first_longer_than_second(word1,word2)