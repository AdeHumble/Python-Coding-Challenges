#6
def same_first_and_last_letter(character):
	while character=="":
		print("You must provide an input. Please, try again!")
		break
	if character[0]==character[-1]:
		print(True)
	else:
		print(False)

print("\tHello! Dear User. This program is written to test that the first and last characters of any word are the same. \n \tIt will return a FALSE statement if it's otherwise and if no input was supplied.")
print("_______"*17)
word=input("Enter any word of your choice, ")
same_first_and_last_letter(word)