#7
def three_number_sum(character):
	add=character[0]+character[1]+character[2]
	print(add)

word=input("Enter any number character of your choice, ")
num_word=int(word)
three_number_sum(num_word)