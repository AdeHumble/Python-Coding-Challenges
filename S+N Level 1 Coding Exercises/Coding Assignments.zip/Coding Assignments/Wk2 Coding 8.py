#8
def first_three_character(character):
	while len(character)<3:
		print("You MUST enter a word with at least 3 characters. \nPlease, TRY AGAIN!")
		break
	else:
		print(character[:3])

print("\tHello! Dear User. This program is written to test prints out the first three characters of your input. \n \tIt will prompts a DEFAULT ERROR STATEMENT if the word is not up to three characters. The program will also AUTOMATICALLY ends. \n \tHave Fun!.")
print("_______"*17)
word=input("Enter any word of your choice, ")
first_three_character(word)