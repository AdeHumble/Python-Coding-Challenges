#9
def last_five_characters(character):
	while len(character)<5:
		print("You MUST enter a word with at least 5 characters. \nPlease, TRY AGAIN!")
		break
	else:
		print(character[-5:])

print("\tHello! Dear User. This program is written to test prints out the last five characters of your input. \n \tIt will prompts a DEFAULT ERROR STATEMENT if the word is not up to five characters. The program will also AUTOMATICALLY ends. \n \tHave Fun!")
print("_______"*17)
word=input("Enter any word of your choice,  ")
last_five_characters(word)