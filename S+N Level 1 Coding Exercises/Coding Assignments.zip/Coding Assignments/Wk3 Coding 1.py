#1
print("Hello, dear user! Let's play a game.\nI'll help you to find the index position of any letter in any word of your choice.\nFeel free")
#This program is written to generate/find the number of vowels in any sentence/word with repetition.
#It's design to be case-insentitive: Hence "i" also implies "I"
#In addition, this program is also diligent to print out the list of vowels found in a particular word/sentence.
#Happy coding!

def vowel_count(user_input):
	vowels=["a", "e", "i", "o", "u"]
	wordvowels=[]
	count=0
	for i in user_input:
		if i==vowels[0]:
			wordvowels.append(vowels[0])
			count+=1
		elif i==vowels[1]:
			wordvowels.append(vowels[1])
			count+=1
		elif i==vowels[2]:
			wordvowels.append(vowels[2])
			count+=1
		elif i==vowels[3]:
			wordvowels.append(vowels[3])
			count+=1
		elif i==vowels[4]:
			wordvowels.append(vowels[4])
			count+=1
	if wordvowels==[]:
		print("There are no vowels in your input", user_input)
	else:
		print("There are",count,"vowels in",user_input)
		print("They are:", end=" ")
		print(wordvowels)
	
print("This program is written to return the number of vowels in a word.\nFeel free!")
print("-----"*24)

word=input("please, enter any word of your choice:  ").lower()
vowel_count(word)