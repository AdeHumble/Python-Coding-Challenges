#10
#This program is written to evaluate the factorial of any number using Recursion method provided the number is neither a negative integer nor a float
def factorial(num):  
   if num== 1:  
       return num
   else:  
       return num*factorial(num-1)  
     
user_value= int(input("Enter any positive number: "))  
if user_value< 0:  
   print("Ooops! factorial does not exist for negative numbers.\nPlease try again!")
elif user_value == 0:  
   print("The factorial of 0 is 1")  
else:  
   print("The factorial of",user_value,"is",factorial(user_value))