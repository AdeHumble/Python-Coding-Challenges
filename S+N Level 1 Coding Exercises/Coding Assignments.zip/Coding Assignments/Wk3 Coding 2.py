#2
def find_my_letter(string,character):
	print(string.find(character))
	
print("Hello, dear user! Let's play a game.\nI'll help you to find the index position of any letter in any word of your choice.\nFeel free")

user_string=input("Enter any word of your choice:  ")
user_character=input("Which alphabet do you wish to look for it index?   ")

find_my_letter(user_string,user_character)