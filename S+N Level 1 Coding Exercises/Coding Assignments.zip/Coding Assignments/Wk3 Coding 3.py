#3
def fancy_cleanup(string):
	print(string.strip().replace(" ","!").replace("g","z"))

user_input=input("Enter any sentence:  ")
fancy_cleanup(user_input)