#4
def even_or_odd(num):
	if num%2==0:
		print("even")
	else:
		print("odd")

print("Hello, dear user! Let's play a game.\nI'll help you decide if a particular number is even or odd.\nFeel free")

user_input=int(input("Enter any number of your choice: "))
even_or_odd(user_input)