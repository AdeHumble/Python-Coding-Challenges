#5
def truthy_or_falsy(anything):
	if anything=="0" or anything=="":
		result=print("falsy")
	else:
		result=print("truthy")
print("This program test for the truthfulnes and falsiness of a statement")

num_char=input("Please, enter anything: ")
truthy_or_falsy(num_char)