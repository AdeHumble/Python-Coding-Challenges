#6
def up_and_down(string):
	if string.isupper():
		print(string.lower())
	elif string.islower():
		print(string.upper())
	else:
		print(string.swapcase())

word=input("Enter anything: ")
up_and_down(word)