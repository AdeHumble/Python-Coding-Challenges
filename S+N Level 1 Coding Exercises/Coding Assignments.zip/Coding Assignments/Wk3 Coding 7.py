#7
def negative_energy(num):
	print(abs(num))

print("This program is written to return the absolute value of any number")
user_value=int(float(input("Enter any number of your choice: ")))
negative_energy(user_value)