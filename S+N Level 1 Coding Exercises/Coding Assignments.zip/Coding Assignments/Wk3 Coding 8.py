#8
def divisible_by_three_and_four(num):
	if num%3==0 and num%4==0:
		print("True")
	else:
		print("False")
print("This program will help you test if a number is divisible by both 3 and 4")
	
user_input=int(input("Enter any number of your choice: "))
divisible_by_three_and_four(user_input)