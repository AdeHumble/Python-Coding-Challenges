#9
def string_theory(string):
	if len(string)>3 and string.startswith("S"):
		print("True")
	else:
		print("False")

user_input=input("Enter any word of your choice: ")
string_theory(user_input)