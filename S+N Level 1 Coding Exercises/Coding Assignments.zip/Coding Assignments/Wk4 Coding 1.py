#1
#a
empty=[]

#b
active=["5" in "12345"]
print(active)

#c
favorite_numbers=[4,9,1,-3,7]

#d
colors=["red", "green", "blue"]

#e
def is_long(expected_list):
	print("True" if len(expected_list)>5 else "False")

print("|||||"*24)
	
user_string=input("Enter any sentence, dont be shy!: ").split(" ")
size=len(user_string)
print("Your input", user_string,"has",size,"items. Hence, it is: ")

is_long(user_string)