#10
print("This program is written to return a list of words with at least 5 characters from your choice input")

print("|||||"*24)


#My Function Program
def long_string(expected_string):
	expected_list=[]
	for i in expected_string:
		if len(i)>=5:
			expected_list.append(i)
	print(expected_list)

#My Main Program
user_list=[]
while True:
	try:
		num=int(input("How many siblings do you have? "))
		break
	except ValueError:
		print("That is a wrong input.\nPlease, enter a postive integer")
		print("|||||"*24)
		
for n in range(num):
	user_string=input("Enter the names of your siblings: ")
	user_list.append(user_string)

long_string(user_list)