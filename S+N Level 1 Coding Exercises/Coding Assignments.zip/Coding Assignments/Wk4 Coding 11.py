#11
print("This program is written to calculates and return all the factors of a whole number")
print("|||||"*24)


#My Function Program
def factors(expected_no):
	factors=[]
	if expected_no<0:
		print("Error! You must enter a POSTIVE whole number.\nPlease, try again!")
	for i in range(1,expected_no+1):
		if 1<=i<=expected_no and expected_no%i==0:
			factors.append(i)
		
	print("The factors of", expected_no,"in ascending order is: ",factors)
		

#My Main Program
while True:
	try:
		user_no=int(input("enter the number: "))
		break
	except ValueError:
		print("oops! That is a wrong input.\nYou MUST enter a positive whole number")
		print("|||||"*24)
	
factors(user_no)