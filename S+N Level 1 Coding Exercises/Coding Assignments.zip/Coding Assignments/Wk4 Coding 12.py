#12
print("This program is written to add your current number (if greater than 5) to the list of previous numbers and delete the last number on the list otherwise.")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by accepting any dynamic input from my user. 

#This program won't continue execution unless the proper data type input is supplied



#My Function Program
def push_or_pop(expected_input):
	expected_list=[]
	for i in expected_input:
		if i>5:
			expected_list.append(i)
		elif i<=5:
			expected_list.pop()
	print(expected_list)
	

#My Main Program
user_list=[]
while True:
	try:
		num=int(input("How many numbers do you want to play with? "))
		break
	except ValueError:
		print("ooops! That's a wrong input.\nYou must enter a whole number.\nPlease, try again!")
		print("|||||"*24)
	
	
for n in range(num):
	while True:
		try:
			user_number=int(input(" Enter those numbers: "))
			break
		except ValueError:
			print("ooops! That's a wrong input.\nYou must enter a whole number.\nPlease, try again!")
		print("|||||"*24)
		
	user_list.append(user_number)
	
push_or_pop(user_list)