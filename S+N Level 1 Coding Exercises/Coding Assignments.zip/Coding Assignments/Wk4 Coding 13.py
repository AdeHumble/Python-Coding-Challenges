#13
print("This program is written to encrypt your input by changing each characters in your word to a corresponding character by stepping it by postion two in the English alphabet.\nDon't mind my epistle. Let's play a game!")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing a any dynamic input from my user, be it in lowercases or uppercases


#My Function Program
def encrypt_message(message):
	encrypted=" "
	alphabets=["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
	
	for letter in message:
		index1=alphabets.index(letter)
		if index1<=23:
			index2=index1+2
			encrypted=encrypted+alphabets[index2]
		elif index1==24:
			encrypted=encrypted+alphabets[0]
		elif index1==25:
			encrypted=encrypted+alphabets[1]
	print(encrypted)
	

#My Main Program
user_word=input("Enter any word you wish to encrypt: ").lower()
print("Your new encrypted word is: ")
encrypt_message(user_word)