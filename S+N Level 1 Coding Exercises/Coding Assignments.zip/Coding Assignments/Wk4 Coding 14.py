#14
print("This program is written to concatenate/join all your inputs with just a space.\nMind you, if your supply an empty value or space(s) as inputs, it's not going to be reflected in the final output.\n Don't mind my epistle. Let's play a game!")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing a any dynamic input from my user

#My Function Program
def cleanup(expected_list):
	print(" ".join(expected_list))



#My Main Program
user_string=[]
while True:
	try:
		num=int(input("How many words do u want to play with? "))
		break
	except ValueError:
		print("ooooops! That is a wrong input.\nYou MUST enter a whole number")
		print("|||||"*24)
for n in range(num):
	user_input=input("Enter any word of your choice: ")
	if user_input.count(" ")>=1 or user_input=="" :
		continue
	user_string.append(user_input)
	

cleanup(user_string)