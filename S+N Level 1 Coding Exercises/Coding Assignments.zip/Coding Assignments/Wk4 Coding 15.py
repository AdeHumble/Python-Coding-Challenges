#15
print("This program is written to concatenate nested lists if and only if the list has just 3 elements.")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing my user to give me various examples of each classes of food. By so doing, i'll be generating a nested list

#My Function Program
def fancy_concatenate(user_list):
	answer=[]
	for l in user_list:
		if len(l)!=3:
			continue
		answer.append("".join(l))
	print("".join(answer))


#My Main Program
universal_list=[]
carb=[]
protein=[]
fat_and_oil=[]
vitamins=[]
water=[]
minerals=[]
fibre=[]

#I am going to limit this program to 3 sublists i.e i'll only be considering carbohydrate, protein and vitamins. That was why i purposely comments out the remaining lines of codes.

while True:
	try:
		num=int(input("How many examples of carbohydrate can you tell me? "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a whole number.\nTry again!")
		print("|||||"*24)
		
for n in range(num):
	c=input("Mention them: ")
	carb.append(c)
universal_list.append(carb)


while True:
	try:
		num1=int(input("How many examples of protein can you tell me? "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a whole number.\nTry again!")
		print("|||||"*24)
		
for n1 in range(num1):
	p=input("Mention them: ")
	protein.append(p)
universal_list.append(protein)


while True:
	try:
		num2=int(input("How many examples of vitamins can you tell :me? "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a whole number.\nTry again!")
		print("|||||"*24)
		
for n2 in range(num2):
	v=input("Mention them ")
	vitamins.append(v)
universal_list.append(vitamins)

#num3=int(input("How many examples of fats & oil can you tell me? "))
#for n3 in range(num3):
#	fo=input("Mention them: ")
#	fat_and_oil.append(fo)
#universal_list.append(fat_and_oil)

#num4=int(input("How many examples of fibre can you tell me? "))
#for n4 in range(num4):
#	f=input("Mention them: ")
#	fibre.append(f)
#universal_list.append(fibre)


#num5=int(input("how many type of minerals do u know? "))
#for n5 in range(num5):
#	m=input("give me examples: ")
#	minerals.append(m)
#listo.append(minerals)


#num6=int(input("how many type of water do u know? "))
#for n6 in range(num6):
#	w=input("give me examples: ")
#	water.append(m)
#listo.append(water)


fancy_concatenate(universal_list)