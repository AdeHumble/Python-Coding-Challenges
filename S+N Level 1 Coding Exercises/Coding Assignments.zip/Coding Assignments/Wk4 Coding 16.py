#16
print("This program is written to filter out the odd elements between two lists inputs of ANY TYPE of user choices.")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by filtering out the odd colour choices of my code user and his/her anonymouus friend

#The Function Program
def destroy_elements(expected_list1,expected_list2):
	odd_element = []
	for a in range(len(expected_list1)):
		if expected_list1[a] not in expected_list2:
			odd_element.append(expected_list1[a])
	print(odd_element)
	
			
#The lines of codes below make use of list comprehension. It can also be used in the function.	
	
#	print([odd_element.append(expected_list1[a]) for a in range(len(expected_list1)) if expected_list1[a] not in expected_list2])



#My Main Code
user_list1=[]
user_list2=[]
while True:
	try:
		num1=int(input("How many favorite colours do you have? "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a whole number.\nTry again!")
		print("|||||"*24)
		
for n1 in range(num1):
	user_string1=input("Help me with tbose colors: ")
	user_list1.append(user_string1)
	
while True:
	try:
		num2=int(input("How many favorite colours does your best friend have? "))
		break
	except ValueError:
		print("Ooopps! That's a wrong input.\nYou must enter a whole number.\nTry again!")
		print("|||||"*24)

for n2 in range(num2):
	user_string2=input("Help me with tbose colors: ")
	user_list2.append(user_string2)

print("The odd colour of your best friend relative to your own favorite.colour is: ")
destroy_elements(user_list1,user_list2)
    