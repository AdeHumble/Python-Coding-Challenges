#2

def first_letter_last_string(expected_list):
	print(expected_list[-1][0])


print("This program will help you remember the first letter of every last word in any sentence of your choice\nAre you ready?\nOkay then, let's start!")

print("|||||"*24)
	
user_string=input("Enter any sentence, don't be shy!: ").split(" ")
print("The first letter of your last word in",user_string,"is: ")
first_letter_last_string(user_string)