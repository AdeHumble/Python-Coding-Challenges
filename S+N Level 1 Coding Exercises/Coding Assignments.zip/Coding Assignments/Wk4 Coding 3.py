#3
#This program is very sensitive to user values. It is designed to keep asking for the right value in case a user enters a wrong input format without altering the program's execution.


def split_in_two(expected_string, number):
	print(expected_string[2:] if (number%2==0) else expected_string[:2])
	
	
user_string=input("Enter any sentence of your choice: ").split(" ")
while True:
	try:
		num=int(input("enter any num: "))
		break
	except ValueError:
		print("Oops! That's a wrong input dear.\nYou MUST enter a whole number.\nPls, try again!")

split_in_two(user_string,num)