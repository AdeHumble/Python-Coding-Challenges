#4

def long_word_in_collection(expected_list,expected_string):
	print("True" if (expected_string in expected_string) and len(expected_string)>4 else "False")
	
	
user_list=input("Please,don't be shy. Enter any sentence: ").split(" ")
user_string=input("Enter any word yoh wish to test: ")

long_word_in_collection(user_list,user_string)