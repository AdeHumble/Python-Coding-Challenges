#5
#This program is very sensitive to user values. It is designed to keep asking for the right value in case a user enters a wrong input format without altering the program's execution.


def product(number_list):
	product=1
	for i in number_list:
		product=product*i
	print(product)


user_number=[]
while True:
	try:
		num=int(input("How many numbers do you wish to find their product? "))
		break
	except ValueError:
		print("Oops! Thats not a number. Try again!")


for i in range(0, num):
	while True:
		try:
			element=int(input("Enter the numbers: "))
			user_number.append(element)
			break
		except ValueError:
			print("Oops! Thats not a number. Try again!")
	

print("The product is: ")		
product(user_number)