#6
print("This program is written to sum the index positions of all the first occurrence of letter 's' in each of your word choice")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing my user to enter the names of his/her secondary school classmates


#My Function Program
def super_sum(expected_names):
	sum=0
	for name in expected_names:
		if "s" in name:
			sum=sum+name.index("s")
	
	print(sum)
	

#My Main Program
user_names=[]
while True:
	try:
		num=int(input("How many students are in your class? "))
		break
	except ValueError:
		print("oopps! That's a wrong input. You must enter a whole integer.\nTry again!")
		print("|||||"*24)
for n in range(num):
	user_name=input("Please, enter the names of your classmates, one after the other: ")
	user_names.append(user_name)
print("The names of your classmates are: ", user_names,"and the sum of all first occurrence of letter 's' is: ")
super_sum(user_names)