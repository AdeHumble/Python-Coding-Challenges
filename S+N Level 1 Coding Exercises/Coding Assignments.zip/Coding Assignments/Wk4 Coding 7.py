#7
print("\tThis program is written to sum the index positions and their corresponding values in the list of your number choices.\n\tMind you,it will ceaselessly ask you for the proper input of an integer in case you entered a wrong input.\nHappy Coding")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing my user to dynamically provide any range of numbers he/she wishes to play with and their values.

#My Function Program
def sum_of_values_and_indices(expected_list):
	indexsum=0
	valuesum=0
	for p in range(len(expected_list)):
		valuesum=valuesum+expected_list[p]
	print(valuesum)
		
	
	for q in expected_list:
		indexsum=indexsum+expected_list.index(q)
		if expected_list.count(q)>1:
			for r in range(1,len(expected_list)):
				indexsum=indexsum+expected_list.index(q,r)
			
		
		
	print(indexsum)	
	print(valuesum+ indexsum)



#My Main Program
numbers=[]
while True:
	try:
		n=int(input("How many numbers do you want to play with? "))
		break
	except ValueError:
		print("Oopss! That's a wrong input.\nYou must enter an integer.\nPlease try again!")
		
for r in range(n):
	while True:
		try:
			num=int(input("enter those numbers: "))
			break
		except ValueError:
			print("Oopss! That's a wrong input.\nYou must enter an integer.\nPlease try again!")
	numbers.append(num)
print(numbers)
sum_of_values_and_indices(numbers)