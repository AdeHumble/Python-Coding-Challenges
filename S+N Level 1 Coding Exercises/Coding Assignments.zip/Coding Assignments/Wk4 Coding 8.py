#7
print("\tThis program is written to return the index position of elements with the same index value in two different list choices.\n\tMind you,it will ceaselessly ask you for the proper input of an integer in case you entered a wrong input.\nHappy Coding")
print("|||||"*24)

#I am going to be demonstrating the functionality of this code by allowing my user to dynamically provide names.of students in two different classes. The program will compare the names in both classes and return the imdex postion of the names having the same index values
#This program is also written to assume equal size/length of both lists 

#My Function Program
def same_index_values(list1,list2):
	answer=[]
	for m in range(len(list1)):
		if list1[m]==list2[m]:
			answer.append(m)
	print(answer)


#My Function Program
class1=[]
class2=[]
while True:
	try:
		num=int(input("How many students are in each class? "))
		break
	except ValueError:
		print("Oopss! That's a wrong input.\nYou must enter an integer.\nPlease try again!")
print("||||"*24)		
for q in range(num):
	classes1=input("Enter the names of the students in class1: ")
	class1.append(classes1)

print("|||||"*24)
for j in range(num):
	classes2=input("Enter the names of the students in class2: ")
	class2.append(classes2)
	
print("The names of students in class1 are: ",class1)
print("The names of students in class2 are: ",class2)

print("The equal index postion is: ")
same_index_values(class1,class2)