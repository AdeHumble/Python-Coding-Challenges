#9
#a
great_directors=[
"Martin Scorsese",
"Steven Spielberg",
"Francis Ford Copoola"
]
#great_directors.insert(1,"Michael Bay")
#great_directors.remove("Steven Spielberg")

great_directors[1]="Michael Bay"

#b
transformers=[
"Optimus prime",
"Megatron",
"Bumblebee",
"Starscream"
]

transformers[2]='Grimlock'

#c
camping_trip_supplies=[
"Socks",
"Flashlight",
"Tent",
"Blanket"
]
camping_trip_supplies[0]="Food"

#d
tech_companies=[
"Google",
"Microsoft",
"Blackberry",
"IBM",
"Yahoo"
]
tech_companies[1:4]=["Facebook", "Apple"]


print(great_directors)
print("|||||"*24)
print(transformers)
print("|||||"*24)
print(camping_trip_supplies)
print("|||||"*24)
print(tech_companies)