#1
print("METHOD 1: Using For-Loop")
#Funtion Program
def right_words(expected_list, expected_no):
	answer=[]
	for words in expected_list:
		if len(words)==expected_no:
			answer.append(words)
	print(answer)


#Main Program	
#The following lines of codes will accepts a list of words
user_list=[]
while True:
	try:
		num=int(input("How many words would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for i in range(num):
	word=input("Enter those words of your choice: ")
	user_list.append(word)

#The following lines of codes will accepts a specific number i.e. word length
print("\n")
while True:
	try:
		n=int(input("What is the size of the length of words that you want? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")

print("The words with",n,"characters are: ")
right_words(user_list,n)
	
print("\n")

print("METHOD 2: Using Filter Function")
#Function Program
def right_words(expected_list):
	return len(expected_list)==n

#Main Program
user_list=[]
while True:
	try:
		num=int(input("How many words would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
print("\n")
		
for i in range(num):
	word=input("Enter those words of your choice: ")
	user_list.append(word)
print("\n")
n=int(input("What is the size of the length of words that you want? "))

print("The words with",n,"characters are: ")
print(list(filter(right_words, user_list)))


print("\n")
print("METHOD 3: Using Lamda Function")
user_list=[]
while True:
	try:
		num=int(input("How many words would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
print("\n")
		
for i in range(num):
	word=input("Enter those words of your choice: ")
	user_list.append(word)

print("\n")	
while True:
	try:
		n=int(input("What is the size of the length of words that you want? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
print("\n")

print("The words with",n,"characters are: ")	
print(list(filter(lambda user: len(user)==n, user_list)))