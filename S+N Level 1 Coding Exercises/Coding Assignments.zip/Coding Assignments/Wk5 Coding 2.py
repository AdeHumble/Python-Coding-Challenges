#2
#This program is written to return the list odd numbers among the number choices of a user

print("METHOD1: Using For-Loop")
#Function Program
def only_odds(expected_list):
	answer=[]
	for num in expected_list:
		if (num%2) != 0:
			answer.append(num)
	return(answer)

#Main Program
user_list=[]
while True:
	try:
		n=int(input("How many numbers would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for i in range(n):
	while True:
		try:
			user_num=int(input("Enter those numbers of your choice: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
			print("\n")
	user_list.append(user_num)
	
print("The odd numbers in", user_list,"are: ",only_odds(user_list))

print("\n")



print("METHOD 2: Using Filter Function")
#Function Program
def only_odds(expected_list):
	return expected_list%2 !=0

#Main Program
user_list=[]
while True:
	try:
		n=int(input("How many numbers do u wish to play with: "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for i in range(n):
	while True:
		try:
			user_num=int(input("Enter those numbers of your choice: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
	user_list.append(user_num)

print("The odd numbers in", user_list,"are: ")
print(list(filter(only_odds, user_list)))
	
print("\n")

print("METHOD 3: Using Lambda Function")

user_list=[]
while True:
	try:
		n=int(input("How many numbers do u wish to play with: "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for i in range(n):
	while True:
		try:
			user_num=int(input("Enter those numbers of your choice: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
	user_list.append(user_num)

print("The odd numbers in", user_list,"are: ")
print(list(filter(lambda user_no: (user_no%2) != 0,user_list)))

