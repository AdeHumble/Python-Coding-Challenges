#3
#This program is written to return a list of the number of  "a" characters in each choices of a user input

#Function Program
def count_of_a(expected_list):
	answer=[]
	for word in expected_list:
		count_a=0
		if "a" in word:
			count_a=word.count("a")
			answer.append(count_a)
		elif "a" not in word:
			answer.append(count_a)
		elif word==" ":
			print(answer)
	print(answer)
			

#Main Program
word_list=[]
while True:
	try:
		num=int(input("How many words would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for n in range(num):
	words=input("Enter those words: ")
	word_list.append(words)

print("The number of 'a' in each of",word_list, "is: ")
count_of_a(word_list)

