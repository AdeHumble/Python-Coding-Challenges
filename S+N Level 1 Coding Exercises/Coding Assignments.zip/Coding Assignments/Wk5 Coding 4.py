#4
#This program is written to return the list of numbers with the greatest sum

#Function Program
def greater_sum(expected_list1,expected_list2):
	if sum(expected_list1)>sum(expected_list2):
		print(expected_list1)
	elif sum(expected_list2)>sum(expected_list1):
		print(expected_list2)
	else:
		print("Both lists are equal")
		

#Main Program
user_list1=[]
while True:
	try:
		n1=int(input("How many numbers do you want to play with in the first list? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for m in range(n1):
	while True:
		try:
			user_num1=int(input("Enter those numbers: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
	if user_num1==[]:
		user_list1.append(0)
	
	user_list1.append(user_num1)
	

user_list2=[]
while True:
	try:
		n2=int(input("How many numbers do you want to play with in the second list? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for n in range(n2):
	while True:
		try:
			user_num2=int(input("Enter those numbers: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
	user_list2.append(user_num2)
	
print("\n")
print("Your first number list is: ", user_list1,"\nand your second number list is:  ", user_list2)
print("Hence, The list with the highest sum is: ")
greater_sum(user_list1,user_list2)