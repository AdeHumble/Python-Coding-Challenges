#5
#This program is written to find the difference between the sum of two different number lists

#Function Program
def sum_difference(expected_list1,expected_list2):
	answer=sum(expected_list1)-sum(expected_list2)
	print(answer)

#Main Program
#The following lines will accepts the first number list
user_list1=[]
while True:
	try:
		n1=int(input("How many numbers do you want to play with in the first list: "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")

for m in range(n1):
	while True:
		try:
			user_num1=int(input("Enter those numbers: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
	user_list1.append(user_num1)

print("\n")

#The following lines will.accepts the second number list
user_list2=[]
while True:
	try:
		n2=int(input("How many numbers do you want to play with in the first list: "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
		print("\n")
		
for n in range(n2):
	while True:
		try:
			user_num2=int(input("Enter those numbers: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
	user_list2.append(user_num2)
print("\n")

print("The diference between the sum of", user_list1, "and", user_list2, "is: ")	
sum_difference(user_list1,user_list2)
