#6
#a
months=("September","October","November","December")


#b
faves=["Power", "Money Heist", "Game of Thrones"]
movies=tuple(faves)


#c
number_a=(3,4,5)
number_b=(6,7,8)
number_c=(1,2,9)
all_numbers=(number_a, number_b, number_c)
