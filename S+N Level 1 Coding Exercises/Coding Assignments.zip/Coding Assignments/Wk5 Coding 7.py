#7
#a
job_opening=("Software Engineer", "New York City", "100000")

position,city,salary = job_opening


#b
address=("35 Elm Street", "San Francisco", "CA", "94107")
street, *city_and_state, zip_code=address


#c
#Function Program
def sum_of_evens_and_odds(expected_tuple):
	answer=[]
	evensum=0
	oddsum=0
	for num in expected_tuple:
		if num%2==0:
			evensum=evensum+num
		if num%2!=0:
			oddsum=oddsum+num
	answer.append(evensum)
	answer.append(oddsum)
	print(tuple(answer))

#Main Program	
Number=[]
while True:
	try:
		n=int(input("How many numbers would you like to play with? "))
		break
	except ValueError:
		print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
print("\n")

for i in range(n):
	while True:
		try:
			number=int(input("Enter those numbers: "))
			break
		except ValueError:
			print("That's a wrong input!\nYou must provide a positive integer. Please, try again.")
	Number.append(number)
	print("\n")

print("The sum of the even numbers and odd numbers respectively in", Number, "is: ")
sum_of_evens_and_odds(Number)