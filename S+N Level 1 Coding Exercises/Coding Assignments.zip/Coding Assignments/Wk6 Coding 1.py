#1
#1a
empty={}
print(empty\n)

print("\n")
#1b
my_dict={"Stephen":45, "Simeon":22, "Solomon":37}
print(my_dict)

print("\n")
#1c
winning_lottery_numbers={

(2>5): False, (5==5.0):True

}
print(winning_lottery_numbers)