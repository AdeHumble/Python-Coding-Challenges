#2
print("This program is written to return a dictionary where the keys represent a length and the values represent how many strings have that length \n")

#FUNCTION PROGRAM
def length_count(userword_list):
	key_value_pair=[]
	dict_list=[]
	answer=[]
	
	
	for userword in userword_list:
		frequency=userword_list.count(userword)
		key_value_pair=[len(userword), frequency]
		if key_value_pair in dict_list:
			key_value_pair=[len(userword),frequency+1]	
		dict_list.append(key_value_pair)
	
#The lines directly below will remove repetitions of each key_value pair
		
		for key_value in dict_list:
			if key_value not in answer:
				answer.append(key_value)
	
		
	print(f"Your word list is {userword_list} and your answer is: \n\n{dict(answer)}")

#MAIN PROGRAM
word_list=[]

while True:
	try:
		num=abs(int(float(input("How many numbers do you want to play with? "))))
		break
	except ValueError:
		print("That is a wrong input. Make sure you enter a number. Please, try again!\n")

print("\n")
for n in range(num):
	word=input("Please, enter your word choices one after the other: ")
	word_list.append(word)
	

print("\n")
length_count(word_list)