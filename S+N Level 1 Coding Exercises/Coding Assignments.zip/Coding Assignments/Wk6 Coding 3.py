#3
#This program is written to return the values of a dictionary keys that are found in a particular list.
print("This program will be making use of the names and ages of a list of students. The user will be prompted to provide the names of the students in which he/she needs the sum of their ages.\nThis program is very very smart. To mention a few of its intelligence, its not going to run into an error in case a user enters any foul student names.\nPlease, feel free to make use of this code in whatever length!\n")



#MAIN PROGRAM
student_list=[]
name_age_pair=[]
student_dict={}
Not_found_Names=[]
Age_sum=0
New_Names=[]

while True:
	try:
		number=abs(int(float(input("How many student names would you like to enter? "))))
		break
	except ValueError:
		print("That is a wrong input. You must provide an integer. Please, try again!\n")

print("\n")
for num in range(number):
	while True:
		try:
			name,age=input("Please, enter the name and age of each student separated by a comma: ").strip().split(",")
			print("\n")
			name_age_pair=[name,abs(int(float((age))))]
			break
		except ValueError:
			print("\nSomething is wrong with your inputs. Please, check for the following errors:\n\n1) Remember you have to enter just a pair of a name and age of each student at once.\n\n2) Only commas are required to separate your inputs.\n\n3) Make sure your second input is an integer.\n\nPlease try again!\n")
		
	student_list.append(name_age_pair)
	student_dict=dict(student_list)
print("Okay good! We are progressing.\n")

Names=input("Enter the names of the students you would like to sum their ages separated by a comma: ").strip().split(",")

print(f"\nThe following are the names of students you want to find the sum of their ages,{Names}\n")

for Name in Names:
	if Name not in student_dict.keys():
		Not_found_Names.append(Name)
		continue
		
	else:
		Age_sum = Age_sum + student_dict.get(Name)

for similar in Names:
	if similar not in Not_found_Names:
		New_Names.append(similar)
		
print(f"The following names: {Not_found_Names} are not in the list of names you entered.\n")

print("\nThe sum of the ages of ",New_Names,"is",Age_sum)