#4
print("This program is written to return a list of items that exist as both a key and a value in a dictionary.\n")


#FUNCTION PROGRAM
def common_elements(expected_dict):
	common_elements=[]
	for key, value in expected_dict.items():
		if key in expected_dict.keys() and key in expected_dict.values():
			common_elements.append(key)
		
	print(f"Your dictionary is: {expected_dict}.\n\nThe common elements in your dictionary are: {common_elements}")	
	
			
#MAIN PROGRAM
pair_list=[]
user_list=[]
user_dict={}

while True:
	try:
		number=abs(int(float(input("How many key-value pairs would you like to enter? "))))
		break
	except ValueError:
		print("That is a wrong input. You must provide an integer. Please, try again!\n")

print("\n")
for num in range(number):
	while True:
		try:
			input1,input2 = input("\nEnter each key-value pair separated by a comma: ").split(",")
			break
		except ValueError:
			print("Something is wrong with your inputs.\n\nRemember you have to enter just a pair of key and value at once, separated by a comma.\nAlso, no spaces are allow. Please try again!\n")
			
	
	pair_list=[input1,input2]
	user_list.append(pair_list)
user_dict=dict(user_list)

print("\n")
common_elements(user_dict)

print("\n")
repeat_factor=input("Would you like to run the program again?\nPlease, select either option A or B\nA) Yes\nB) No        ").upper()
	
if repeat_factor=="A":
	pair_list=[]
	user_list=[]
	user_dict={}
			
	while True:
		try:
			number=abs(int(float(input("How many key-value pairs would you like to enter? "))))
			break
		except ValueError:
			print("That is a wrong input. You must provide an integer. Please, try again!\n")
				
	for num in range(number):
		while True:
			try:
				input1,input2 = input("\nEnter each key-value pair separated by a comma: ").split(",")
				break
			except ValueError:
				print("Something is wrong with your inputs.\n\nRemember you have to enter just a pair of key and value at once, separated by a comma.\nAlso, no spaces are allow. Please try again!\n")
				
		pair_list=[input1,input2]
		user_list.append(pair_list)
	user_dict=dict(user_list)
			
	print("\n")
	common_elements(user_dict)
		
elif repeat_factor=="B":
		print("Thank your for using this program. See you next time!")
		
else:
	print("You entered an incorrect option. Your choices are only limited to A or B. Bye!")