complexity={

{
"Fawas":True, "Idris": False
},


{9.75: ["FUTA", "OAU", "FUNAAB", "Covenant"], 20.9: ["7.25", "9"], 678.35: ["Chemist", "Engineer", "Architect"]},


{
"Soccer": False, "Hockey": True
},

{"52.10":["Ronaldinho", "Mikel_Obi"],"1.9":["Bola", "Dog", "Cat", "Tunde"],"48.27":["Carbohydrates", "Vitamins", "Minerals"]}



}


print(complexity)