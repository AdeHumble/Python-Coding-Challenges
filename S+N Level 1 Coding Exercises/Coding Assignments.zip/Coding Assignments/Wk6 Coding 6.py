#6
print("This program is written to return True if the sum of your number choices is greater than 100 and return False otherwise.\n\nFeel free to enter any range of numbers.")

#FUNCTION PROGRAM
def plenty_arguments(a,b,*args,**kwargs):
	
	result=a+b
	for arg in args:
		result=result+arg
	for value in kwargs.values():
		result=result+value
	
	if result>100:
		print(f"The sum of your numbers is greater than 100. Hence, it's: \n\n{True}")
	else:
		print(f"The sum of your numbers is not not greater than 100. Hence, it's: \n\n{False}")


#MAIN PROGRAM
user_list=[]

while True:
	try:
		number=abs(int(float(input("\nHow many numbers would you like to enter? "))))
		break
	except ValueError:
		print("That was a wrong input! You must enter an integer value. Please, try again!\n")

print("\n")
for num in range(number):				

	while True:
		try:
			user_num=int(input("Enter those numbers you would like to check for their sum  one after the other: "))
			break
		except ValueError:
			print("That was pretty wrong. You must enter any integer. Please, try again! \n")
	user_list.append(user_num)


print(f"\nYour number choices are: {user_list}\n")
plenty_arguments(*user_list)