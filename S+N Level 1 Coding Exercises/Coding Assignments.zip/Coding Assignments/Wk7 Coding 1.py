#1
#This program is written to simply demonstrates how a class can be created and how to instantiate objects from a class blueprint.


class Superhero():
	"""This is an empty class."""
	pass

		
#The following lines are the objects made from the blueprint of a Superhero class.
	
spiderman=Superhero()
batman=Superhero()
superman=Superhero()


#The following prints statements, if uncommented, validates that the corresponding print statements arguments are real objects made from the Superhero class.

#print(spiderman)
#print(batman)
#print(superman)