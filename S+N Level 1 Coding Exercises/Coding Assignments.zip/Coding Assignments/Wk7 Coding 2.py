#2
#This program is written to demonstrates a simple class that creates and accepts instances.


class Skyscraper():
	"""
	This is a class with two attrubutes and it's being used to creates two different objects.
	
	"""
	
	def __init__(self,name,year):
		self.name=name
		self.year=year
		
	
	
#The following lines are the objects made from the blueprint of a Skyscraper class with their respective instances.
		
empire=Skyscraper("Empire State Building", 1931)
wtc=Skyscraper(year=2014, name="One World Trade Centre")



#The following prints statements, if uncommented, validates that the corresponding print statements arguments are executable for each Skyscraper class objects.

#print(wtc.name)
#print("\n",empire.year)