#3
#zombie.py
#This program is written to demonstrates a simple class and how to instantiates a class objects with default values using postional and keyword arguments.


class Zombie():
	def __init__(self,health=100, brains_eaten=5):
		self.health=health
		self.brains_eaten=brains_eaten

bob=Zombie(80,brains_eaten=5)
sally=Zombie(120,3)
benjamin=Zombie()


#The following prints statements, if uncommented, validates that the corresponding print statements arguments returns the the state of each class objects.

#print(bob.health)
#print("\n",sally.brains_eaten)
#print("\n",benjamin.health)