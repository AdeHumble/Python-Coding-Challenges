#4
#This program demonstrates how to create a clsss method

class Chocolate():
	
	def __init__(self):
		self.cacao_content="cacao_content"
	
	@classmethod
	def sweet(cls):
		cacao_content=30
		return cacao_content
		
	@classmethod
	def semisweet(cls):
		cacao_content=50
		return cacao_content
		
	@classmethod
	def bittersweet(cls):
		cacao_content=70
		return cacao_content
		
	@classmethod
	def bitter(cls):
		cacao_content=99
		return cacao_content

#Here, i used "choco" to instantiate a class object				
choco=Chocolate()


#The print statements below, if umcommented, will validate that the program is void of errors.

print(choco.semisweet())