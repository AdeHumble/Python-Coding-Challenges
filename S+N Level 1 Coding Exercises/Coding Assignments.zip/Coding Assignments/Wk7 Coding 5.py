#5
#This program demonstrates how to use a namedtuple to creates a class.

import collections as collect
import time

#This will creates a class
GymExercise=collect.namedtuple("GymExercise", ["name", "weight", "reps"])

#The following lines represents GymExercise class created objects

squat=GymExercise(reps=3, weight=265, name="squat")

bench=GymExercise(name="benchpress",weight=185,reps=5)

deadlift=GymExercise("deadlift", reps=6, weight= 225)

press=GymExercise("press",120,8)



#If uncommented, the following print statements would validate that the above codes will run seamlessly without errors

#print(squat.weight)
#print(bench.name)
#print(deadlift.name)
#print(press.reps)

time.sleep(5) #This will end the program only after 5second.