#6
#This program demonstrates the idea of inheritance

class Store():
	"""This is a superclass"""
	def __init__(self):
		self.owner="Boris"
	
	def exclaim(self):
		return "I'm defined in the superclass!"
		
#This HardwareStore class will inherits the instance methods from a Store superclass
class HardwareStore(Store):
	"""This is a subclass"""
	pass

#This is class object created from HardwareStore subclass	
home_depot=HardwareStore()

print(home_depot.owner)
print("\n")
print(home_depot.exclaim())