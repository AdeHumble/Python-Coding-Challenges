#7
#This program demonstrates the idea of class inheritance and how to overwrite instance methods


class Clothing():
	"""This is a superclass"""
	
	def wear(self):
		return "I'm wearing this fashionable piece of clothing!"
	
	def sell(self):
		return "Buy my piece of clothing!"
	
class Socks(Clothing):
	"""This is a sub#lass"""
	
	def lose_one(self):
		return "Where did my other one go?"
	
	def wear(self):
		return "Take a look at my socks they are gorgeous!"
		
	def sell(self):
		return "Buy my socks!"

#This is an object created from Socks subclass
clean_socks=Socks()
	

print(clean_socks.wear())
print("\n",clean_socks.lose_one())